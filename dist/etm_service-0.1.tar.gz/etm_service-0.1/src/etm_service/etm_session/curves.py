from .session import ETMSession

class ETMCurvesSession(ETMSession):
    pass
