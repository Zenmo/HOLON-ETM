class BaseConverter:
    def __init__(self, *values):
        pass

    def calculate(self):
        pass

    def required_for_calculation(self):
        yield
